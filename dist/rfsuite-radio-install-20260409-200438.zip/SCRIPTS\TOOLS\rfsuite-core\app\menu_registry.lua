local MenuRegistry = {}
local EMPTY_ENTRIES = {}

local function wipeTable(t)
  if type(t) ~= "table" then return end
  for k in pairs(t) do t[k] = nil end
end

local function populateDynamicMenus(menus)
  if type(menus) ~= "table" then return end

  -- Populate settings_dashboard_settings_menu dynamically
  local dashboardMenu = menus["settings_dashboard_settings_menu"]
  if type(dashboardMenu) == "table" and dashboardMenu._dynamicThemes == true then
    local dashboardBuilder = assert(loadScript("/SCRIPTS/TOOLS/rfsuite-core/app/lib/dashboard_builder.lua", "t"))()
    local entries, themeMenus = dashboardBuilder.buildDashboardSettingsThemeMenus()
    dashboardMenu.pages = entries

    -- Add theme-specific menus to the registry
    if type(themeMenus) == "table" then
      for menuId, menuDef in pairs(themeMenus) do
        menus[menuId] = menuDef
      end
    end
  end
end

function MenuRegistry.new(manifest, i18n, options)
  options = options or {}
  local iconByMenuId = options.iconByMenuId or {}

  local menus = manifest.menus or {}
  populateDynamicMenus(menus)

  local self = {
    i18n = i18n,
    sections = manifest.sections or {},
    menus = menus,
    conditions = options.conditions or {},
    activeSectionId = nil,
    currentMenuId = nil,
    currentEntryId = nil,
    breadcrumbStack = {},
    _titleCache = {},
    _cachedLocale = nil,
    _conditionsVersion = 0,
    _rootCache = {locale = nil, iconRoot = nil, version = -1, data = nil},
    _cardsCache = {locale = nil, iconRoot = nil, menuId = nil, version = -1, data = nil}
  }

  local function currentLocale()
    if i18n and i18n.getLocale then
      return i18n.getLocale()
    end
    return nil
  end

  local function invalidateCaches()
    self._rootCache.locale = nil
    self._rootCache.iconRoot = nil
    self._rootCache.version = -1
    self._rootCache.data = nil

    self._cardsCache.locale = nil
    self._cardsCache.iconRoot = nil
    self._cardsCache.menuId = nil
    self._cardsCache.version = -1
    self._cardsCache.data = nil
  end

  local function refreshLocaleCaches()
    local locale = currentLocale()
    if self._cachedLocale ~= locale then
      self._cachedLocale = locale
      wipeTable(self._titleCache)
      invalidateCaches()
    end
  end

  local function isEntryEnabled(entry)
    if type(entry) ~= "table" then
      return false
    end

    if entry.enabled == false then
      return false
    end

    local conditionKey = entry.enabledWhen
    if conditionKey == nil then
      return true
    end

    if type(conditionKey) == "string" then
      return self.conditions[conditionKey] == true
    end

    if type(conditionKey) == "function" then
      return conditionKey(self.conditions, entry) == true
    end

    return true
  end

  local function resolveTitle(entry)
    if type(entry) ~= "table" then
      return ""
    end

    refreshLocaleCaches()

    local cached = self._titleCache[entry]
    if cached ~= nil then return cached end

    local resolved = ""

    if entry.titleKey then
      resolved = i18n.t(entry.titleKey)
    elseif entry.title then
      resolved = i18n.resolve(entry.title)
    end

    self._titleCache[entry] = resolved or ""
    return self._titleCache[entry]
  end

  local function resolveIconPath(iconRoot, icon, menuId)
    if type(icon) == "string" and icon ~= "" then
      if string.sub(icon, 1, 1) == "/" then
        return icon
      end
      if string.sub(icon, 1, 7) == "@pages/" then
        return "/SCRIPTS/TOOLS/rfsuite-core/app/pages/" .. string.sub(icon, 8)
      end
      return iconRoot .. icon
    end

    local pageIcon = menuId and iconByMenuId[menuId] or nil
    if type(pageIcon) == "string" and pageIcon ~= "" then
      return "/SCRIPTS/TOOLS/rfsuite-core/app/pages/" .. pageIcon
    end

    return nil
  end

  local function getSectionById(id)
    for i = 1, #self.sections do
      if self.sections[i].id == id then
        return self.sections[i]
      end
    end
    return nil
  end

  local function getCurrentContainer()
    if self.currentMenuId then
      return self.menus[self.currentMenuId]
    end
    return nil
  end

  local function getCurrentEntries()
    local container = getCurrentContainer()
    if not container then return EMPTY_ENTRIES end
    return container.pages or {}
  end

  local function syncCurrentEntry()
    local entries = getCurrentEntries()
    if #entries == 0 then
      self.currentEntryId = nil
      return
    end

    for i = 1, #entries do
      if entries[i].id == self.currentEntryId then
        return
      end
    end

    self.currentEntryId = entries[1].id
  end

  local function pushBreadcrumb(kind, id, title)
    self.breadcrumbStack[#self.breadcrumbStack + 1] = {
      kind = kind,
      id = id,
      title = title
    }
  end

  local function resetBreadcrumbForSection(section)
    self.breadcrumbStack = {}
    pushBreadcrumb("section", section.id, resolveTitle(section))
  end

  if #self.sections > 0 then
    local firstSection = self.sections[1]
    self.activeSectionId = firstSection.id
    self.currentMenuId = nil
    self.breadcrumbStack = {}
    self.currentEntryId = nil
  end

  function self.getActiveSection()
    return getSectionById(self.activeSectionId)
  end

  function self.setActiveSection(id)
    local section = getSectionById(id)
    if not section then return false end

    self.activeSectionId = id
    self.currentMenuId = nil
    resetBreadcrumbForSection(section)
    syncCurrentEntry()
    return true
  end

  function self.isRoot()
    return self.currentMenuId == nil
  end

  function self.getRootGroups(iconRoot)
    refreshLocaleCaches()
    local cache = self._rootCache
    if cache.data and cache.locale == self._cachedLocale and cache.iconRoot == iconRoot and cache.version == self._conditionsVersion then
      return cache.data
    end

    local groups = {}
    for i = 1, #self.sections do
      local section = self.sections[i]
      local entries = section.pages or {}
      local cards = {}

      for j = 1, #entries do
        local p = entries[j]
        local enabled = isEntryEnabled(p)
        if not (enabled == false and p.hideWhenDisabled == true) then
          cards[#cards + 1] = {
          id = p.id,
          sectionId = section.id,
          row = p.row or 1,
          col = p.col or j,
          data = {
            text = resolveTitle(p),
            icon = resolveIconPath(iconRoot, p.icon, p.menuId),
            isMenu = p.menuId ~= nil,
            enabled = enabled
          }
        }
        end
      end

      groups[i] = {
        id = section.id,
        title = resolveTitle(section),
        cards = cards
      }
    end

    cache.locale = self._cachedLocale
    cache.iconRoot = iconRoot
    cache.version = self._conditionsVersion
    cache.data = groups

    return groups
  end

  function self.openRootEntry(sectionId, entryId)
    local section = getSectionById(sectionId)
    if not section then return false end

    local entries = section.pages or {}
    for i = 1, #entries do
      local entry = entries[i]
      if entry.id == entryId then
        if not isEntryEnabled(entry) then
          return false
        end

        self.activeSectionId = sectionId
        self.currentEntryId = entryId
        resetBreadcrumbForSection(section)

        if entry.menuId and self.menus[entry.menuId] then
          self.currentMenuId = entry.menuId
          pushBreadcrumb("menu", entry.menuId, resolveTitle(self.menus[entry.menuId]))
          syncCurrentEntry()
        end

        self._cardsCache.data = nil

        return true
      end
    end

    return false
  end

  function self.openEntry(id)
    local entries = getCurrentEntries()
    for i = 1, #entries do
      local entry = entries[i]
      if entry.id == id then
        if not isEntryEnabled(entry) then
          return false
        end

        self.currentEntryId = id
        if entry.menuId and self.menus[entry.menuId] then
          self.currentMenuId = entry.menuId
          pushBreadcrumb("menu", entry.menuId, resolveTitle(self.menus[entry.menuId]))
          syncCurrentEntry()
          self._cardsCache.data = nil
        end
        return true
      end
    end
    return false
  end

  function self.goBack()
    if not self.currentMenuId then
      return false
    end

    self.breadcrumbStack[#self.breadcrumbStack] = nil
    local parent = self.breadcrumbStack[#self.breadcrumbStack]

    if not parent then
      self.currentMenuId = nil
      local section = self.getActiveSection()
      if section then
        resetBreadcrumbForSection(section)
      end
      syncCurrentEntry()
      return true
    end

    if parent.kind == "section" then
      self.currentMenuId = nil
      self.currentEntryId = nil
    elseif parent.kind == "menu" then
      self.currentMenuId = parent.id
    end

    syncCurrentEntry()
    self._cardsCache.data = nil
    return true
  end

  function self.getBreadcrumb()
    local parts = {}
    for i = 1, #self.breadcrumbStack do
      local title = self.breadcrumbStack[i].title
      if title and title ~= "" then
        parts[#parts + 1] = title
      end
    end

    return table.concat(parts, " / ")
  end

  function self.getHeaderTitle()
    if self:isRoot() then
      local section = self.getActiveSection()
      return section and resolveTitle(section) or ""
    end

    local top = self.breadcrumbStack[#self.breadcrumbStack]
    return (top and top.title) or ""
  end

  function self.getHeaderBreadcrumb()
    if self:isRoot() then
      return ""
    end

    local parts = {}
    for i = 1, (#self.breadcrumbStack - 1) do
      local title = self.breadcrumbStack[i].title
      if title and title ~= "" then
        parts[#parts + 1] = title
      end
    end

    return table.concat(parts, " / ")
  end

  function self.getCards(iconRoot)
    refreshLocaleCaches()
    local cache = self._cardsCache
    if cache.data and cache.locale == self._cachedLocale and cache.iconRoot == iconRoot and cache.menuId == self.currentMenuId and cache.version == self._conditionsVersion then
      return cache.data
    end

    local entries = getCurrentEntries()
    local cards = {}
    for i = 1, #entries do
      local p = entries[i]
      local enabled = isEntryEnabled(p)
      if not (enabled == false and p.hideWhenDisabled == true) then
      local row = p.row or math.floor((i - 1) / 3) + 1
      local col = p.col or ((i - 1) % 3) + 1
      cards[#cards + 1] = {
        id = p.id,
        row = row,
        col = col,
        data = {
          text = resolveTitle(p),
          icon = resolveIconPath(iconRoot, p.icon, p.menuId),
          isMenu = p.menuId ~= nil,
          enabled = enabled
        }
      }
      end
    end

    cache.locale = self._cachedLocale
    cache.iconRoot = iconRoot
    cache.menuId = self.currentMenuId
    cache.version = self._conditionsVersion
    cache.data = cards

    return cards
  end

  function self.getCurrentEntryId()
    return self.currentEntryId
  end

  function self.getCurrentMenuId()
    return self.currentMenuId
  end

  function self.isRootEntryEnabled(sectionId, entryId)
    local section = getSectionById(sectionId)
    if not section then
      return false
    end

    local entries = section.pages or {}
    for i = 1, #entries do
      local entry = entries[i]
      if entry.id == entryId then
        return isEntryEnabled(entry)
      end
    end

    return false
  end

  function self.isEntryEnabled(entryId)
    local entries = getCurrentEntries()
    for i = 1, #entries do
      local entry = entries[i]
      if entry.id == entryId then
        return isEntryEnabled(entry)
      end
    end

    return false
  end

  function self.setCondition(key, value)
    local nextValue = value == true
    if self.conditions[key] == nextValue then return end
    self.conditions[key] = nextValue
    self._conditionsVersion = self._conditionsVersion + 1
    invalidateCaches()
  end

  return self
end

return MenuRegistry
