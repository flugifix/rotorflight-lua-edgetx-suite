local M = {}

local function loadModule(path)
  local fullPath = "/SCRIPTS/TOOLS/rfsuite-core/" .. path
  local chunk = assert(loadScript(fullPath, "t"))
  return chunk()
end

local Controls = loadModule("ui/controls.lua")
local Common = loadModule("app/pages/settings/common.lua")

local CONFIG_SCHEMA = {
  { key = "debug_level", type = "string", default = "off" },
  { key = "enable_serial_debug", type = "bool", default = false }
}

local DEBUG_LEVEL_VALUES = { "off", "info", "debug" }

local function buildDefaultConfig()
  local cfg = {}
  for _, field in ipairs(CONFIG_SCHEMA) do
    cfg[field.key] = field.default
  end
  return cfg
end

local ui = {
  loaded = false,
  dirty = false,
  sections = {
    logging = true
  },
  config = buildDefaultConfig()
}

ui.runtime = Common.createFormRuntime(ui)
ui.runtime.valueGetters = {}
ui.runtime.valueSetters = {}

local t = Common.pageT("settings_developer_settings")

local function prefBool(value, default)
  if value == nil then return default end
  return value == true or value == "true" or value == 1 or value == "1"
end

local function copyFromPrefs(prefs)
  local general = (prefs and prefs.general) or {}
  for _, field in ipairs(CONFIG_SCHEMA) do
    local raw = general[field.key]
    if field.type == "number" then
      ui.config[field.key] = tonumber(raw) or field.default
    elseif field.type == "string" then
      local text = tostring(raw or "")
      if text == "" then text = field.default end
      ui.config[field.key] = string.lower(text)
    else
      ui.config[field.key] = prefBool(raw, field.default)
    end
  end

  local current = ui.config.debug_level
  if current ~= "off" and current ~= "info" and current ~= "debug" then
    ui.config.debug_level = "off"
  end
end

local function ensureLoaded(prefs)
  if ui.loaded then return end
  copyFromPrefs(prefs)
  ui.loaded = true
  ui.dirty = false
end

local function getValueGetter(key)
  local getter = ui.runtime.valueGetters[key]
  if getter then return getter end

  getter = function()
    return ui.config[key]
  end
  ui.runtime.valueGetters[key] = getter
  return getter
end

local function getValueSetter(key)
  local setter = ui.runtime.valueSetters[key]
  if setter then return setter end

  setter = function(value)
    if ui.config[key] == value then return end
    ui.config[key] = value
    ui.runtime.markDirty()
  end
  ui.runtime.valueSetters[key] = setter
  return setter
end

local function buildDebugLevelOptions(i18n)
  return {
    { value = "off",   label = t(i18n, "debug_level_off", "OFF") },
    { value = "info",  label = t(i18n, "debug_level_info", "INFO") },
    { value = "debug", label = t(i18n, "debug_level_debug", "DEBUG") }
  }
end

local function buildLogging(cursorY, children, x, w, i18n)
  cursorY = cursorY + Controls.appendComboSelect(children, x, cursorY, w,
    t(i18n, "debug_level", "Debug Level"),
    buildDebugLevelOptions(i18n),
    getValueGetter("debug_level")(),
    getValueSetter("debug_level")
  )

  cursorY = cursorY + Controls.appendRadioSwitch(children, x, cursorY, w,
    t(i18n, "enable_serial_debug", "Enable Serial Debug"),
    ui.runtime.getBoolGetter("enable_serial_debug"),
    ui.runtime.getBoolSetter("enable_serial_debug")
  )
  return cursorY
end

local SECTIONS = {
  {
    key = "logging",
    titleKey = "section_logging",
    titleFallback = "Logging",
    build = buildLogging
  }
}

function M.getHeaderActions()
  return { save = ui.dirty, reload = true, help = false }
end

function M.allowMemAutoRefresh()
  return true
end

function M.onReload(ctx)
  copyFromPrefs(ctx.preferences)
  ui.dirty = false
end

function M.onSave(ctx)
  if not ctx.preferences.general then ctx.preferences.general = {} end

  for _, field in ipairs(CONFIG_SCHEMA) do
    ctx.preferences.general[field.key] = ui.config[field.key]
  end

  local ok, err = ctx.savePreferences()
  if ok then
    ui.dirty = false
    if lvgl and lvgl.alert then
      lvgl.alert({ title = t(ctx.i18n, "saved_title", "Saved"), message = t(ctx.i18n, "saved_message", "Developer settings saved") })
    end
  else
    if lvgl and lvgl.alert then
      lvgl.alert({ title = t(ctx.i18n, "save_error_title", "Error"), message = t(ctx.i18n, "save_error_message", "Save failed") .. ": " .. tostring(err or "io") })
    end
  end
end

function M.build(ctx)
  ensureLoaded(ctx.preferences)

  local children = ctx.children
  local x, w = ctx.x, ctx.w
  local i18n = ctx.i18n
  ui.runtime.setRequestRebuild(ctx.requestRebuild)
  local cursorY = ctx.y

  for i, section in ipairs(SECTIONS) do
    if i > 1 then cursorY = cursorY + 10 end

    local key = section.key
    Controls.appendSectionHeader(children, x, cursorY, w,
      t(i18n, section.titleKey, section.titleFallback),
      ui.sections[key],
      ui.runtime.getSectionToggleHandler(key)
    )

    cursorY = cursorY + Controls.SECTION_H
    if ui.sections[key] then
      cursorY = section.build(cursorY, children, x, w, i18n)
    end
  end
end

return M
