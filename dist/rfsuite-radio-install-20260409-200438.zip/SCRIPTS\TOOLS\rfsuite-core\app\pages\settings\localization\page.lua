local M = {}

local function loadModule(path)
  local fullPath = "/SCRIPTS/TOOLS/rfsuite-core/" .. path
  local chunk = assert(loadScript(fullPath, "t"))
  return chunk()
end

local Controls = loadModule("ui/controls.lua")
local Common = loadModule("app/pages/settings/common.lua")

-- ─── Config schema ────────────────────────────────────────────────────────────
-- All persisted localization settings. Loading and saving are automatic.
--   type "number" → tonumber() coercion, default must be a number

local CONFIG_SCHEMA = {
  { key = "temperature_unit", type = "number", default = 0 },
  { key = "altitude_unit",    type = "number", default = 0 },
}

local function buildDefaultConfig()
  local cfg = {}
  for _, field in ipairs(CONFIG_SCHEMA) do cfg[field.key] = field.default end
  return cfg
end

-- ─── State ────────────────────────────────────────────────────────────────────

local ui = {
  loaded    = false,
  dirty     = false,
  language  = "en",
  config    = buildDefaultConfig(),
}

ui.runtime = Common.createFormRuntime(ui)

-- ─── Helpers ─────────────────────────────────────────────────────────────────

local t = Common.pageT("settings_localization")

local function copyFromPrefs(prefs)
  local loc = (prefs and prefs.localizations) or {}
  local general = (prefs and prefs.general) or {}

  local language = tostring(general.language or "")
  language = string.lower(language)
  if language ~= "de" and language ~= "en" then
    language = "en"
  end
  ui.language = language

  for _, field in ipairs(CONFIG_SCHEMA) do
    ui.config[field.key] = tonumber(loc[field.key]) or field.default
  end
end

local function ensureLoaded(prefs)
  if ui.loaded then return end
  copyFromPrefs(prefs)
  ui.loaded = true
  ui.dirty  = false
end

local function getTempOptions(i18n)
  return {
    { value = 0, label = t(i18n, "temp_celsius", "Celsius") },
    { value = 1, label = t(i18n, "temp_fahrenheit", "Fahrenheit") },
  }
end

local function getAltOptions(i18n)
  return {
    { value = 0, label = t(i18n, "alt_meter", "Meter") },
    { value = 1, label = t(i18n, "alt_feet", "Feet") },
  }
end

local function getLanguageOptions(i18n)
  return {
    { value = "en", label = t(i18n, "language_en", "English") },
    { value = "de", label = t(i18n, "language_de", "Deutsch") },
  }
end

-- ─── Section builder ─────────────────────────────────────────────────────────

local function buildLocalization(cursorY, children, x, w, i18n)
  cursorY = cursorY + Controls.appendComboSelect(
    children, x, cursorY, w,
    t(i18n, "language", "Language"),
    getLanguageOptions(i18n),
    ui.language,
    function(val)
      local nextLang = tostring(val or "")
      nextLang = string.lower(nextLang)
      if nextLang ~= "de" and nextLang ~= "en" then
        nextLang = "en"
      end
      if ui.language == nextLang then return end
      ui.language = nextLang
      ui.runtime.markDirty()
    end
  )

  cursorY = cursorY + Controls.appendComboSelect(
    children, x, cursorY, w,
    t(i18n, "temperature_unit", "Temperatureinheit"),
    getTempOptions(i18n),
    ui.config.temperature_unit,
    function(val)
      ui.config.temperature_unit = val
      ui.runtime.markDirty()
    end
  )

  cursorY = cursorY + Controls.appendComboSelect(
    children, x, cursorY, w,
    t(i18n, "altitude_unit", "Hoeheneinheit"),
    getAltOptions(i18n),
    ui.config.altitude_unit,
    function(val)
      ui.config.altitude_unit = val
      ui.runtime.markDirty()
    end
  )

  return cursorY
end

-- ─── Module API ──────────────────────────────────────────────────────────────

function M.getHeaderActions()
  return { save = ui.dirty, reload = true, help = false }
end

function M.allowMemAutoRefresh()
  return true
end

function M.onReload(ctx)
  copyFromPrefs(ctx.preferences)
  ui.dirty = false
end

function M.onSave(ctx)
  if not ctx.preferences.localizations then ctx.preferences.localizations = {} end
  if not ctx.preferences.general then ctx.preferences.general = {} end

  ctx.preferences.general.language = ui.language

  for _, field in ipairs(CONFIG_SCHEMA) do
    ctx.preferences.localizations[field.key] = ui.config[field.key]
  end
  local ok, err = ctx.savePreferences()
  if ok then
    ui.dirty = false
    if lvgl and lvgl.alert then
      lvgl.alert({ title = t(ctx.i18n, "saved_title", "Gespeichert"), message = t(ctx.i18n, "saved_message", "Einstellungen gespeichert") })
    end
  else
    if lvgl and lvgl.alert then
      lvgl.alert({ title = t(ctx.i18n, "save_error_title", "Fehler"), message = t(ctx.i18n, "save_error_message", "Speichern fehlgeschlagen") .. ": " .. tostring(err or "io") })
    end
  end
end

function M.build(ctx)
  ensureLoaded(ctx.preferences)

  local children = ctx.children
  local x, w = ctx.x, ctx.w
  local i18n = ctx.i18n
  local cursorY = ctx.y

  ui.runtime.setRequestRebuild(ctx.requestRebuild)
  buildLocalization(cursorY, children, x, w, i18n)
end

return M
